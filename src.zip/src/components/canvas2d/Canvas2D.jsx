import { useRef, useEffect, useState } from "react";
import { 默认视图范围, 像素转数学 } from "../../utils/mathToScreen";
import { 画网格 } from "../../drawing/draw2d/drawGrid";
import { 画坐标轴 } from "../../drawing/draw2d/drawAxes";
import { 画曲线 } from "../../drawing/draw2d/drawCurve";
import { 画切线 } from "../../drawing/draw2d/drawTangent";
import { 画点 } from "../../drawing/draw2d/drawPoint";
import { 画黎曼矩形 } from "../../drawing/draw2d/drawRiemann";
import { 画十字准星 } from "../../drawing/draw2d/drawCrosshair";
import { 画函数标签 } from "../../drawing/draw2d/drawLabel";
import { 解析表达式 } from "../../math/parse";
import { 计算曲线点 } from "../../math/evaluate";
import { 取导数 } from "../../math/derivative";
import { 画泰勒 } from "../../drawing/draw2d/drawTaylor";
import { 取泰勒 } from "../../math/taylor";
import { 求容差区间 } from "../../math/errorInterval";
import { 视野重置桥 } from "../../utils/viewReset";

const 动画周期 = 6000;

// 画布宽高比和 mathToScreen 里默认视图范围的比例一致
const 宽高比 = 1.5;

// 两层画布叠放：
//   底层 —— 网格、坐标轴、曲线、黎曼、泰勒、切线。只在函数/视野/动画/尺寸
//     变化时重画。这一层很贵（自适应采样 + 积分填充）。
//   顶层 —— 只有十字准星和悬停读数。鼠标每动一下只重画这层，
//     成本是每条函数一次代入求值，不再触发全量重采样。
// 之前合在一层、effect 依赖里有「鼠标位置」：鼠标一晃所有函数重新采样，
// 准星掉到十几帧。
function Canvas2D({ 函数列表 }) {
  const 底层Ref = useRef(null);
  const 顶层Ref = useRef(null);
  const 容器Ref = useRef(null);

  const [视图范围, 设置视图范围] = useState(默认视图范围);
  const [动画进度, 设置动画进度] = useState(0);
  const [画布尺寸, 设置画布尺寸] = useState({ 宽: 1200, 高: 800 });
  // 高分屏：画布内部像素要按设备像素比放大，否则浏览器会把图拉伸放大 → 糊
  // 封顶 2 是为了不在 3x 屏上白白画 9 倍的像素
  const [像素比, 设置像素比] = useState(() =>
    Math.min(window.devicePixelRatio || 1, 2)
  );

  const [鼠标位置, 设置鼠标位置] = useState(null);
  // 数学坐标，离开时为 null

  const 拖拽中 = useRef(false);
  const 上次鼠标 = useRef({ x: 0, y: 0 });

  const 需要动画 = 函数列表.some((项) => 项.追踪函数 || 项.追踪切线);

  // 画布跟随容器宽度，并且始终保持固定宽高比
  useEffect(() => {
    const 容器 = 容器Ref.current;
    if (!容器) return;

    function 重新测量(可用宽) {
      const 最大高 = Math.max(240, window.innerHeight - 280);
      let 宽 = Math.max(320, Math.round(可用宽));
      let 高 = Math.round(宽 / 宽高比);
      if (高 > 最大高) {
        高 = 最大高;
        宽 = Math.round(高 * 宽高比);
      }
      设置画布尺寸({ 宽, 高 });
    }

    const 观察器 = new ResizeObserver((条目) => {
      重新测量(条目[0].contentRect.width);
    });
    观察器.observe(容器);

    // 把窗口拖到另一块屏上，devicePixelRatio 会变
    function 同步像素比() {
      设置像素比(Math.min(window.devicePixelRatio || 1, 2));
    }
    window.addEventListener("resize", 同步像素比);

    return () => {
      观察器.disconnect();
      window.removeEventListener("resize", 同步像素比);
    };
  }, []);

  // 重置视野的入口挂在导航栏上（按钮在「2D 图形」旁边），
  // 通过桥对象把 设置视图范围 递出去；卸载时摘掉，避免误调已卸载组件
  useEffect(() => {
    视野重置桥.重置 = () => 设置视图范围(默认视图范围);
    return () => {
      视野重置桥.重置 = null;
    };
  }, []);

  // 滚轮缩放：必须用原生监听器 + passive: false
  // React 的 onWheel 是 passive 的，preventDefault 不生效，
  // 结果是图缩放了、页面也跟着滚 —— 两件事同时发生
  // 监听器挂在顶层画布上：它叠在最上面，事件先落到它
  useEffect(() => {
    const 画板 = 顶层Ref.current;
    if (!画板) return;

    function 处理滚轮(事件) {
      事件.preventDefault();
      const 缩放系数 = 事件.deltaY < 0 ? 0.9 : 1.1;

      设置视图范围((旧范围) => {
        const x中心 = (旧范围.x最小 + 旧范围.x最大) / 2;
        const y中心 = (旧范围.y最小 + 旧范围.y最大) / 2;
        const 新x半宽 = ((旧范围.x最大 - 旧范围.x最小) / 2) * 缩放系数;
        const 新y半高 = ((旧范围.y最大 - 旧范围.y最小) / 2) * 缩放系数;

        return {
          x最小: x中心 - 新x半宽,
          x最大: x中心 + 新x半宽,
          y最小: y中心 - 新y半高,
          y最大: y中心 + 新y半高,
        };
      });
    }

    画板.addEventListener("wheel", 处理滚轮, { passive: false });
    return () => 画板.removeEventListener("wheel", 处理滚轮);
  }, []);

  // 动画循环功能：按真实时间进行，不依赖帧率无关
  useEffect(() => {
    if (!需要动画) return;

    let 帧id;
    let 起始时间 = null;

    function 每帧(时间戳) {
      if (起始时间 === null) 起始时间 = 时间戳;
      const 已过 = (时间戳 - 起始时间) % 动画周期;
      设置动画进度(已过 / 动画周期);
      帧id = requestAnimationFrame(每帧);
    }

    帧id = requestAnimationFrame(每帧);
    return () => cancelAnimationFrame(帧id);
  }, [需要动画]);

  // ———————— 底层：静态内容（贵，不跟鼠标走） ————————
  useEffect(() => {
    const 画板 = 底层Ref.current;
    if (!画板) return;

    const ctx = 画板.getContext("2d");
    // 逻辑尺寸用 CSS 尺寸，缩放交给 transform —— 下游画图代码不用改
    const 画布宽 = 画布尺寸.宽;
    const 画布高 = 画布尺寸.高;
    ctx.setTransform(像素比, 0, 0, 像素比, 0, 0);

    ctx.clearRect(0, 0, 画布宽, 画布高);
    画网格(ctx, 画布宽, 画布高, 视图范围);
    画坐标轴(ctx, 画布宽, 画布高, 视图范围);

    函数列表.forEach((项) => {
      if (!项.表达式) return;

      try {
        const 解析结果 = 解析表达式(项.表达式);
        if (!解析结果 || !解析结果.成功) return;

        const 计算函数 = 解析结果.计算函数;
        const 点数组 = 计算曲线点(计算函数, 视图范围, 画布宽 / 2);

        // 黎曼矩形展示功能：垫在曲线下面，优先进行
        if (项.显示积分) {
          const 当前n = Number.isFinite(项.当前n) && 项.当前n > 0 ? 项.当前n : 1;
          画黎曼矩形(
            ctx,
            计算函数,
            项.积分下限,
            项.积分上限,
            当前n,
            项.端点方式,
            画布宽,
            画布高,
            视图范围,
            项.颜色
          );
        }

        // 原函数：追踪时只画到进度位置，否则整条画完
        if (项.追踪函数) {
          const 可见数量 = Math.max(2, Math.floor(点数组.length * 动画进度));
          const 部分点 = 点数组.slice(0, 可见数量);
          画曲线(ctx, 部分点, 画布宽, 画布高, 视图范围, 项.颜色, 计算函数);

          const 末点 = 部分点[部分点.length - 1];
          if (末点) {
            画点(ctx, 末点.x, 末点.y, 画布宽, 画布高, 视图范围, 项.颜色);
          }
        } else {
          画曲线(ctx, 点数组, 画布宽, 画布高, 视图范围, 项.颜色, 计算函数);
          画函数标签(
            ctx,
            点数组,
            项.表达式,
            画布宽,
            画布高,
            视图范围,
            项.颜色
          );
        }

        // 导函数：同色虚线。符号求导优先，拿不到才退回数值
        if (项.显示导数) {
          const 导 = 取导数(项.表达式, 计算函数, 1);
          // 导数只在原函数有定义的地方存在：
          // 原函数无定义的地方（ln(x+1) 在 x<=-1、1/x 在 0），导数同样不画
          const 导求值 = (x) => {
            try {
              return Number.isFinite(计算函数(x)) ? 导.求值(x) : NaN;
            } catch {
              return NaN;
            }
          };
          const 导数点数组 = 计算曲线点(导求值, 视图范围, 画布宽 / 2);
          ctx.setLineDash([6, 4]);
          画曲线(
            ctx,
            导数点数组,
            画布宽,
            画布高,
            视图范围,
            项.颜色,
            导求值
          );
          ctx.setLineDash([]);
        }

        // 泰勒多项式
        if (项.显示泰勒) {
          const a = Number.isFinite(项.展开点a) ? 项.展开点a : 0;
          const n = Number.isFinite(项.泰勒阶数) ? 项.泰勒阶数 : 1;

          let 泰勒 = null;
          try {
            泰勒 = 取泰勒(项.表达式, 计算函数, a, n);
          } catch {
            泰勒 = null;
          }

          if (泰勒 && 泰勒.可用) {
            let 容差区间 = null;
            if (项.显示容差区间) {
              try {
                容差区间 = 求容差区间(计算函数, 泰勒, 项.容差 || 1e-3);
              } catch {
                容差区间 = null;
              }
            }

            画泰勒(
              ctx,
              泰勒,
              计算函数,
              画布宽,
              画布高,
              视图范围,
              项.颜色,
              { 显示误差带: 项.显示误差带, 容差区间 }
            );
          }
        }

        // 切线：追踪模式下切点跟着动画走，其次用滑块的值
        if (项.显示切线 || 项.追踪切线) {
          const 切点 = 项.追踪切线
            ? 视图范围.x最小 + (视图范围.x最大 - 视图范围.x最小) * 动画进度
            : Number.isFinite(项.切点x)
              ? 项.切点x
              : 0;

          const 斜率 = 取导数(项.表达式, 计算函数, 1).求值(切点);
          画切线(ctx, 计算函数, 切点, 斜率, 画布宽, 画布高, 视图范围);
        }
      } catch (错误) {
        // 这条函数画不出来进行跳过，并且在控制台留痕，避免排查时一片空白
        console.error("画函数出错:", 项.表达式, 错误);
        ctx.setLineDash([]);
      }
    });
  }, [函数列表, 视图范围, 动画进度, 画布尺寸, 像素比]);

  // ———————— 顶层：十字准星 + 悬停读数（便宜，跟鼠标走） ————————
  useEffect(() => {
    const 画板 = 顶层Ref.current;
    if (!画板) return;

    const ctx = 画板.getContext("2d");
    const 画布宽 = 画布尺寸.宽;
    const 画布高 = 画布尺寸.高;
    ctx.setTransform(像素比, 0, 0, 像素比, 0, 0);

    ctx.clearRect(0, 0, 画布宽, 画布高);
    if (!鼠标位置 || 拖拽中.current) return;

    // 每条函数在光标 x 处的值。解析走了缓存，每条只剩一次代入求值
    const 读数列表 = [];
    for (const 项 of 函数列表) {
      if (!项.表达式) continue;
      try {
        const 解析结果 = 解析表达式(项.表达式);
        if (!解析结果 || !解析结果.成功) continue;
        读数列表.push({
          表达式: 项.表达式,
          颜色: 项.颜色,
          值: 解析结果.计算函数(鼠标位置.x),
        });
      } catch {
        /* 半截表达式跳过 */
      }
    }

    画十字准星(
      ctx,
      鼠标位置.x,
      鼠标位置.y,
      画布宽,
      画布高,
      视图范围,
      读数列表
    );
  }, [鼠标位置, 视图范围, 画布尺寸, 函数列表, 像素比]);

  // 把浏览器事件坐标换算成画布内部逻辑像素（CSS 尺寸）
  function 取画布内像素(事件) {
    const 画板 = 顶层Ref.current;
    const 矩形 = 画板.getBoundingClientRect();
    return {
      像素x: (事件.clientX - 矩形.left) * (画布尺寸.宽 / 矩形.width),
      像素y: (事件.clientY - 矩形.top) * (画布尺寸.高 / 矩形.height),
    };
  }
  function 处理按下(事件) {
    拖拽中.current = true;
    上次鼠标.current = { x: 事件.clientX, y: 事件.clientY };
  }

  function 处理移动(事件) {
    const 画板 = 顶层Ref.current;
    if (!画板) return;

    // 不拖拽时：记录光标位置，供十字准星使用
    if (!拖拽中.current) {
      const { 像素x, 像素y } = 取画布内像素(事件);
      const 数学 = 像素转数学(
        像素x,
        像素y,
        画布尺寸.宽,
        画布尺寸.高,
        视图范围
      );
      设置鼠标位置({ x: 数学.数学x, y: 数学.数学y });
      return;
    }

    const 画布宽 = 画布尺寸.宽;
    const 画布高 = 画布尺寸.高;

    const 像素偏移x = 事件.clientX - 上次鼠标.current.x;
    const 像素偏移y = 事件.clientY - 上次鼠标.current.y;

    设置视图范围((旧范围) => {
      const 数学每像素x = (旧范围.x最大 - 旧范围.x最小) / 画布宽;
      const 数学每像素y = (旧范围.y最大 - 旧范围.y最小) / 画布高;

      const 数学偏移x = 像素偏移x * 数学每像素x;
      const 数学偏移y = 像素偏移y * 数学每像素y;

      return {
        x最小: 旧范围.x最小 - 数学偏移x,
        x最大: 旧范围.x最大 - 数学偏移x,
        y最小: 旧范围.y最小 + 数学偏移y,
        // y 轴方向相反，所以是 +
        y最大: 旧范围.y最大 + 数学偏移y,
      };
    });

    上次鼠标.current = { x: 事件.clientX, y: 事件.clientY };
  }

  function 处理松开() {
    拖拽中.current = false;
  }

  function 处理离开() {
    拖拽中.current = false;
    设置鼠标位置(null);
    // 光标出界就收起准星
  }

  return (
    <div ref={容器Ref} className="画布区">
      {/* 边框挂在外层 div 上：两层画布内容区才能完全对齐
          两层都是：内部像素 = CSS 尺寸 × 像素比，CSS 尺寸固定为逻辑尺寸 */}
            <div
        className="画布框"
        style={{
          position: "relative",
          width: 画布尺寸.宽,
          height: 画布尺寸.高,
        }}
      >
        <canvas
          ref={底层Ref}
          className="底层画布"
          width={Math.round(画布尺寸.宽 * 像素比)}
          height={Math.round(画布尺寸.高 * 像素比)}
          style={{
            width: `${画布尺寸.宽}px`,
            height: `${画布尺寸.高}px`,
            display: "block",
          }}
        />

        <canvas
          ref={顶层Ref}
          width={Math.round(画布尺寸.宽 * 像素比)}
          height={Math.round(画布尺寸.高 * 像素比)}
          style={{
            position: "absolute",
            left: 0,
            top: 0,
            width: `${画布尺寸.宽}px`,
            height: `${画布尺寸.高}px`,
            cursor: 拖拽中.current ? "grabbing" : "crosshair",
            display: "block",
          }}
          onMouseDown={处理按下}
          onMouseMove={处理移动}
          onMouseUp={处理松开}
          onMouseLeave={处理离开}
        />
      </div>
    </div>
  );
}

export default Canvas2D;
